package com.accomoda.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hotels")
public class Hotel {
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private int hotelId;
	private String hotelName;
	private String city;
	private String state;
	private String country;
	private int pinCode;
	private String hotelType;
	private String amenities;
	private int noOfStandardRooms;
	private int noOfDeluxeRooms;
	private int noOfExecutiveRooms;
	private int noOfConnectingRooms;
	private int noOfSuits;
	private boolean isHomestay;
	
	public Hotel() {
		
	}

	public Hotel(int hotelId, String hotelName, String city, String state, String country, int pinCode,
			String hotelType, String amenities, int noOfStandardRooms, int noOfDeluxeRooms, int noOfExecutiveRooms,
			int noOfConnectingRooms, int noOfSuits, boolean isHomestay) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.city = city;
		this.state = state;
		this.country = country;
		this.pinCode = pinCode;
		this.hotelType = hotelType;
		this.amenities = amenities;
		this.noOfStandardRooms = noOfStandardRooms;
		this.noOfDeluxeRooms = noOfDeluxeRooms;
		this.noOfExecutiveRooms = noOfExecutiveRooms;
		this.noOfConnectingRooms = noOfConnectingRooms;
		this.noOfSuits = noOfSuits;
		this.isHomestay = isHomestay;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public String getHotelType() {
		return hotelType;
	}

	public void setHotelType(String hotelType) {
		this.hotelType = hotelType;
	}

	public String getAmenities() {
		return amenities;
	}

	public void setAmenities(String amenities) {
		this.amenities = amenities;
	}

	public int getNoOfStandardRooms() {
		return noOfStandardRooms;
	}

	public void setNoOfStandardRooms(int noOfStandardRooms) {
		this.noOfStandardRooms = noOfStandardRooms;
	}

	public int getNoOfDeluxeRooms() {
		return noOfDeluxeRooms;
	}

	public void setNoOfDeluxeRooms(int noOfDeluxeRooms) {
		this.noOfDeluxeRooms = noOfDeluxeRooms;
	}

	public int getNoOfExecutiveRooms() {
		return noOfExecutiveRooms;
	}

	public void setNoOfExecutiveRooms(int noOfExecutiveRooms) {
		this.noOfExecutiveRooms = noOfExecutiveRooms;
	}

	public int getNoOfConnectingRooms() {
		return noOfConnectingRooms;
	}

	public void setNoOfConnectingRooms(int noOfConnectingRooms) {
		this.noOfConnectingRooms = noOfConnectingRooms;
	}

	public int getNoOfSuits() {
		return noOfSuits;
	}

	public void setNoOfSuits(int noOfSuits) {
		this.noOfSuits = noOfSuits;
	}

	public boolean isHomestay() {
		return isHomestay;
	}

	public void setHomestay(boolean isHomestay) {
		this.isHomestay = isHomestay;
	}

	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", city=" + city + ", state=" + state
				+ ", country=" + country + ", pinCode=" + pinCode + ", hotelType=" + hotelType + ", amenities="
				+ amenities + ", noOfStandardRooms=" + noOfStandardRooms + ", noOfDeluxeRooms=" + noOfDeluxeRooms
				+ ", noOfExecutiveRooms=" + noOfExecutiveRooms + ", noOfConnectingRooms=" + noOfConnectingRooms
				+ ", noOfSuits=" + noOfSuits + ", isHomestay=" + isHomestay + "]";
	}
	
//	INSERT INTO hotels() values(1,"Atithi","Shegaon","Maharashtra","India",44403,"Premium","Gym Pool Laundry",3,2,2,2,4,false);	
//	INSERT INTO hotels() values(2,"Atithi2","Akola","Maharashtra","India",411003,"Budget","Gym ",3,2,2,2,4,false);
//	INSERT INTO hotels() values(3,"Atithi3","Pune","Maharashtra","India",411222,"Premium","Gym Pool Laundry Breakfast",3,2,3,2,5,false);	
//	INSERT INTO hotels() values(4,"Atithi Niwas","Indore","Madhya Pradesh","India",411456,"Free","Breakfast",0,0,0,0,0,true);	
//	INSERT INTO hotels() values(5,"Reddy Niwas","Chennai","Tamilnadu","India",478486,"Free","Breakfast",0,0,0,0,0,true);
//	INSERT INTO hotels() values(6,"Atithi6","Jaipur","Rajasthan","India",434001,"Premium","Gym Pool Breakfast",3,2,3,3,5,false);	
//	INSERT INTO hotels() values(0,"Atithi7","Surat","Gujrat","India",400124,"Budget","Breakfast",3,2,3,3,5,false);
//
}
